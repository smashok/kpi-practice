﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;

namespace Lab1_1
{
    public class FormLogin : Form
    {

        static Customer customer;
        public Button auth_btn;
        public Label username_label;
        public Label password_label;
        public TextBox username;
        public TextBox password;
        public bool Show;
        public FormLogin()
        {
            username_label = new Label();
            username_label.Text = "Username";
            username_label.Size = new Size(60, 20);
            username_label.Location = new Point(30, 30);
            this.Controls.Add(username_label);

            password_label = new Label();
            password_label.Text = "Password";
            password_label.Size = new Size(60, 20);
            password_label.Location = new Point(30, 60);
            this.Controls.Add(password_label);

            username = new TextBox();
            username.Size = new Size(100, 40);
            username.Location = new Point(90, 30);
            this.Controls.Add(username);

            password = new TextBox();
            password.Size = new Size(100, 40);
            password.Location = new Point(90, 60);
            this.Controls.Add(password);

            auth_btn = new Button();
            auth_btn.Size = new Size(80, 25);
            auth_btn.Location = new Point(80, 120);
            auth_btn.Text = "Auth";
            this.Controls.Add(auth_btn);
            auth_btn.Click += new EventHandler(auth_btn_Click);
        }

        private void auth_btn_Click(object sender, EventArgs e)
        {
            Database.FillDatabase();
            Show = true;
            foreach (Customer c in Database.customers)
            {
                Console.Write("f");
                if (c.CheckLogin(username.Text, password.Text))
                {
                    this.Hide();
                    Form t = new FormChoose();
                    t.Show();
                    customer = c;
                    Show = false;
                }
            }
            if (Show)
            {
                MessageBox.Show("Wrong credits!");
            }
            
        }
    }

    public class FormChoose : Form
    {

        public Button search_btn;
        public Button make_order;
        public FormChoose()
        {
            search_btn = new Button();
            search_btn.Size = new Size(80, 25);
            search_btn.Location = new Point(80, 40);
            search_btn.Text = "Search";
            this.Controls.Add(search_btn);
            search_btn.Click += new EventHandler(search_btn_Click);

            make_order = new Button();
            make_order.Size = new Size(80, 25);
            make_order.Location = new Point(80, 120);
            make_order.Text = "Make Order";
            this.Controls.Add(make_order);
            make_order.Click += new EventHandler(make_order_btn_Click);
        }

        private void search_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form t = new FromSearch();
            t.Show();
        }

        private void make_order_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form t = new FromOrder();
            t.Show();
        }
    }


    public class FromSearch : Form
    {

        public Button search_btn;
        public Button back;
        public TextBox search_querry;
        public Label search_querry_label;
        public Label search_querry_result;
        public Label search_querry_result1;
        public FromSearch()
        {

            search_querry_label = new Label();
            search_querry_label.Text = "Name";
            search_querry_label.Size = new Size(60, 20);
            search_querry_label.Location = new Point(30, 20);
            this.Controls.Add(search_querry_label);

            search_querry_result = new Label();
            search_querry_result.Text = "Shop:";
            search_querry_result.Size = new Size(200, 20);
            search_querry_result.Location = new Point(30, 90);
            this.Controls.Add(search_querry_result);

            search_querry_result1 = new Label();
            search_querry_result1.Text = "Product:";
            search_querry_result1.Size = new Size(200, 20);
            search_querry_result1.Location = new Point(30, 120);
            this.Controls.Add(search_querry_result1);


            search_querry = new TextBox();
            search_querry.Size = new Size(100, 40);
            search_querry.Location = new Point(90, 20);
            this.Controls.Add(search_querry);

            search_btn = new Button();
            search_btn.Size = new Size(80, 25);
            search_btn.Location = new Point(100, 60);
            search_btn.Text = "Search";
            this.Controls.Add(search_btn);
            search_btn.Click += new EventHandler(search_btn_Click);

            back = new Button();
            back.Size = new Size(80, 25);
            back.Location = new Point(10, 60);
            back.Text = "Back";
            this.Controls.Add(back);
            back.Click += new EventHandler(back_btn_Click);

        }

        private void search_btn_Click(object sender, EventArgs e)
        {
            string name = search_querry.Text;//Console.ReadLine();
            bool found = false;

            foreach (Shop s in Database.shops)
            {
                foreach (Product p in s.Products)
                {
                    if (p.Name == name)
                    {
                        search_querry_result.Text = " " + s;
                        search_querry_result1.Text = " " + p;
                        Console.WriteLine(s + "\n" + p + "\n");
                        found = true;
                    }
                }
            }

            if (!found)
            {
                MessageBox.Show("Product not found.Please, try again!");
            }
        }


        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form t = new FormChoose();
            t.Show();

        }
    }


    public class FromOrder : Form
    {

        public Button search_btn;
        public Button back;
        public TextBox search_querry;
        public Label search_querry_label;
        public Label search_querry_result;
        public Label search_querry_result1;
        public FromOrder()
        {

            search_querry_label = new Label();
            search_querry_label.Text = "Name";
            search_querry_label.Size = new Size(60, 20);
            search_querry_label.Location = new Point(30, 20);
            this.Controls.Add(search_querry_label);

            search_querry_result = new Label();
            search_querry_result.Text = "Shop:";
            search_querry_result.Size = new Size(200, 20);
            search_querry_result.Location = new Point(30, 90);
            this.Controls.Add(search_querry_result);

            search_querry_result1 = new Label();
            search_querry_result1.Text = "Product:";
            search_querry_result1.Size = new Size(200, 20);
            search_querry_result1.Location = new Point(30, 120);
            this.Controls.Add(search_querry_result1);


            search_querry = new TextBox();
            search_querry.Size = new Size(100, 40);
            search_querry.Location = new Point(90, 20);
            this.Controls.Add(search_querry);

            search_btn = new Button();
            search_btn.Size = new Size(80, 25);
            search_btn.Location = new Point(100, 60);
            search_btn.Text = "Search";
            this.Controls.Add(search_btn);
            search_btn.Click += new EventHandler(search_btn_Click);

            back = new Button();
            back.Size = new Size(80, 25);
            back.Location = new Point(10, 60);
            back.Text = "Back";
            this.Controls.Add(back);
            back.Click += new EventHandler(back_btn_Click);

        }

        private void search_btn_Click(object sender, EventArgs e)
        {
            Order order = new Order();
            order.products = new List<Product>();
            string name = search_querry.Text;
            bool found = false;

            foreach (Shop s in Database.shops)
            {
                foreach (Product p in s.Products)
                {
                    if (p.Name == name)
                    {
                        search_querry_result.Text = " " + s;
                        search_querry_result1.Text = " " + p;
                        Console.WriteLine(s + "\n" + p + "\n");
                        found = true;

                        order.ShopID = s.ID;
                        order.products.Add(p);
                        Console.WriteLine("Product added to cart.");
                        MessageBox.Show("Product added to cart.");

                    }
                }
            }
            if (found)
            {
                Database.orders.Add(order);
                // Menu();
            }
            else
            {
                Console.WriteLine("Product not found. Please, try again!");
                MessageBox.Show("Product not found.Please, try again!");
            }
        
        }


        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form t = new FormChoose();
            t.Show();

        }
    }

    class Program
    {

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormLogin());
        }

        static void Order()
        {
            Order order = new Order();
            order.products = new List<Product>();
            while (true)
            {
                Console.Write("Please, enter wanted product name: ");
                string name = Console.ReadLine();
                bool found = false;

                foreach (Shop s in Database.shops)
                {
                    foreach (Product p in s.Products)
                    {
                        if (p.Name == name)
                        {
                            Console.WriteLine(s + "\n" + p + "\n");
                            found = true;

                            Console.Write("Add this to cart (y/n)?");
                            string ans = Console.ReadLine();

                            if (ans == "y")
                            {
                                order.ShopID = s.ID;
                                order.products.Add(p);
                                Console.WriteLine("Product added to cart.");
                                continue;
                            }
                            else if (ans == "n")
                            {
                                continue;
                            }
                            else
                            {
                                Console.WriteLine("Wrong input!");
                            }                            
                        }
                    }
                }
                if (found)
                {
                    Database.orders.Add(order);
                   // Menu();
                }
                else
                {
                    Console.WriteLine("Product not found. Please, try again!");
                }
            }
        }
    }
}